import Calculator from './components/Calculator';

import React from 'react';

const App = () => {
    return (
        <div>
            <Calculator title="Calculatrice avec Redux"/>
        </div>
    );
};

export default App;