// Constantes qui contiennent tous les types d'action de l'appli

export const NUMBER1 = 'NUMBER1';
export const NUMBER2 = 'NUMBER2';
export const ADDITION = 'ADDITION';
export const MULTIPLICATION = 'MULTIPLICATION';