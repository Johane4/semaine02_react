//import { NUMBER1 } from "../constants/constants";

// export const Number1 = payload => ({
//     type: NUMBER1, payload
// })

// const actionContact = {
//     type: "GET_CONTACT",
//     payload: {
//         number: '0878656',
//         adress: 'uigbuibgu',
//     }
// }


