import { createContext } from 'react';

const NumberContext = createContext({});

export default NumberContext;