import Numbers from './Numbers';

const Container = () => {
    return (
        <div>
            <Numbers />
        </div>
    )
}

export default Container;