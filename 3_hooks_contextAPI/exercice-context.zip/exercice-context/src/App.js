import './App.css';
import Container from './components/Container';

 const App = () => {

    return (
        <div className="container">
            <Container />
        </div>
    )
}


export default App;
